/* Includes
 *
 *
 *
 *
 * TARIM IOT KARTINDAKİ MCU,GSM VE TTL PİNLERİNİ BİRBİRİNE BAĞLAYINIZ. TX VE RX İÇİN 3ER 3ER BAĞLANIR.
 * BU KOD POSTMAN SİTESİNE AZIMECH YAZISI GÖNDERİR VE KARTTAKİ TTL BAĞLANTISI KULLANILARAK İŞLEM ADIMLARI GÖSTERİLİR
 * KARTI DIŞARIDAN BESLEYİNİZ VE MAVİ GSM NETLIGHT YANMIYORSA RESETLEYİP BEKLEYİNİZ
 *
 *
 *
 *
 *  ------------------------------------------------------------------*/
#include "main.h"
#include <string.h>
#include "stdio.h"
#include "stdint.h"
/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

uint8_t rx_data;
char rx_buffer[100];
uint8_t rx_index = 0;
uint8_t ok_received = 0;

/* Function prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);

/* Main ----------------------------------------------------------------------*/
int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();

  HAL_UART_Receive_IT(&huart1, &rx_data, 1);

  // GSM modülünü başlat (PB3 HIGH sonra LOW)
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
  HAL_Delay(1000);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);
  HAL_Delay(10000); // GSM modül açılış süresi
  // AT komutu gönder
     char *at_command = "AT\r\n";
     HAL_UART_Transmit(&huart1, (uint8_t*)at_command, strlen(at_command), HAL_MAX_DELAY);

     HAL_Delay(1000); // GSM cevaplamak için zaman alsın

     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QICSGP=1,\"internet\"\r\n", 24, HAL_MAX_DELAY); // Operatörüne göre APN değişebilir
     HAL_Delay(2000);

     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+CFUN=1,1\r\n", 13, HAL_MAX_DELAY); // GSM modülü reset
     HAL_Delay(4000);

     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QIREGAPP\r\n", 13, HAL_MAX_DELAY); // APN yapılandırma
     HAL_Delay(7000);

     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QIACT\r\n", 10, HAL_MAX_DELAY); // GPRS bağlantısını aktifleştir
     HAL_Delay(5000);



     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPURL=28,80\r\n", 20, HAL_MAX_DELAY);
     HAL_Delay(4000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"http://postman-echo.com/post\r\n", 50, HAL_MAX_DELAY);
     HAL_Delay(4000);

     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPPOST=19,80,80\r\n", 25, HAL_MAX_DELAY);
     HAL_Delay(5000);  // İşlenmesini bekleyelim

     HAL_UART_Transmit(&huart1, (uint8_t*)"{\"msg\":\"AZIMECH\"}\r\n", 20, HAL_MAX_DELAY);
     HAL_Delay(5000);  // İşlenmesini bekleyelim

     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPREAD\r\n", 14, HAL_MAX_DELAY);
     HAL_Delay(5000);





     /*
     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPURL=41,80\r\n", 19, HAL_MAX_DELAY);
     HAL_Delay(1000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"http://iomechapi.rollmech.com/iomech/post\r\n", 42, HAL_MAX_DELAY);
     HAL_Delay(1000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPPOST=10,80,80\r\n", 24, HAL_MAX_DELAY);
     HAL_Delay(1000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"{\"msg\":\"io\"}\r\n", 12, HAL_MAX_DELAY);
     HAL_Delay(10000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPREAD\r\n", 14, HAL_MAX_DELAY);
     HAL_Delay(10000);
*/




     /*HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPCFG=\"sslctxid\",1\r\n", 26, HAL_MAX_DELAY);
     HAL_Delay(2000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QSSLCFG=\"sslversion\",1,3\r\n", 30, HAL_MAX_DELAY);
     HAL_Delay(2000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QSSLCFG=\"cacert\",1,\"RAM:cacert.pem\"\r\n", 42, HAL_MAX_DELAY);
     HAL_Delay(2000);



     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPURL=42,80\r\n", 20, HAL_MAX_DELAY);
     HAL_Delay(2000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"https://iomechapi.rollmech.com/iomech/add\r\n", 43, HAL_MAX_DELAY);
     HAL_Delay(2000);

     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPHEADER=30\r\n", 19, HAL_MAX_DELAY);
     HAL_Delay(7000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"Content-Type: application/json\r\n", 32, HAL_MAX_DELAY);
     HAL_Delay(7000);

     HAL_UART_Transmit(&huart1, (uint8_t*)"AT+QHTTPPOST=78,30,30\r\n", 23, HAL_MAX_DELAY);
     HAL_Delay(2000);
     HAL_UART_Transmit(&huart1, (uint8_t*)"{\"deviceId\":\"20250317\",\"windDirection\":1,\"windStrength\":2,\"temperature\":3,\"soilMoisture\":4}\r\n", 78, HAL_MAX_DELAY);
     HAL_Delay(5000);*/

  while (1)
  {




  }
}



/* System Clock Configuration */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK) Error_Handler();
}

/* USART1 init */
static void MX_USART1_UART_Init(void)
{
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK) Error_Handler();
}

/* USART2 init */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK) Error_Handler();
}

/* GPIO init (PB3 = GSM power) */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* Error handler */
void Error_Handler(void)
{
  __disable_irq();
  while (1) {}
}
